from GameGUI import *
if __name__ == "__main__":
    store = GameStore()
    gui = GameStoreGUI(store)
