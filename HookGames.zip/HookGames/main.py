from GameGUI import *
from GameStore import GameStore
if __name__ == "__main__":
    store = GameStore()
    gui = GameStoreGUI(store)
